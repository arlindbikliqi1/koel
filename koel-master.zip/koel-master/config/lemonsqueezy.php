<?php

return [
    'store_id' => 62685,
    'product_id' => env('PLUS_PRODUCT_ID', '58e8adbc-b1aa-43f9-b768-a52d1d8e6a40'),
];
