<?php

namespace App\Values\SongStorageMetadata;

final class S3LambdaMetadata extends S3CompatibleMetadata
{
}
