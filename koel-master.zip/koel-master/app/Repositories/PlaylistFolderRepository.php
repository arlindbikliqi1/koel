<?php

namespace App\Repositories;

use App\Models\PlaylistFolder;

/**
 * @extends Repository<PlaylistFolder>
 */
class PlaylistFolderRepository extends Repository
{
}
