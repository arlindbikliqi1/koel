<?php

namespace App\Http\Requests\API\ObjectStorage\S3;

use App\Http\Requests\API\ObjectStorage\Request as BaseRequest;

class Request extends BaseRequest
{
}
