<?php

namespace App\Http\Requests\API;

use App\Http\Requests\Request as BaseRequest;

abstract class Request extends BaseRequest
{
}
