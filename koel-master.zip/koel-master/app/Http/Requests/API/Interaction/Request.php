<?php

namespace App\Http\Requests\API\Interaction;

use App\Http\Requests\API\Request as BaseRequest;

abstract class Request extends BaseRequest
{
}
