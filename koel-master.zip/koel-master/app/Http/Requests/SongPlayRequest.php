<?php

namespace App\Http\Requests;

/**
 * @property float|string $time
 * @property string $api_token
 */
class SongPlayRequest extends Request
{
}
