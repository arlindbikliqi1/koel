<?php

namespace App\Http\Requests;

/**
 * @property-read string $state
 * @property-read string $code
 */
class SpotifyCallbackRequest extends Request
{
}
