<?php

namespace App\Exceptions;

use Exception;

class NotAPlaylistCollaboratorException extends Exception
{
}
