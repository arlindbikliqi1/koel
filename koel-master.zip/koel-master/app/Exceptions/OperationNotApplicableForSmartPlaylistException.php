<?php

namespace App\Exceptions;

use Exception;

class OperationNotApplicableForSmartPlaylistException extends Exception
{
}
