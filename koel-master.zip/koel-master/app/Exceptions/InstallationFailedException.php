<?php

namespace App\Exceptions;

use RuntimeException;

class InstallationFailedException extends RuntimeException
{
}
