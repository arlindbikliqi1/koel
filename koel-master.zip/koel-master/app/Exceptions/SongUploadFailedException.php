<?php

namespace App\Exceptions;

use Exception;

class SongUploadFailedException extends Exception
{
}
