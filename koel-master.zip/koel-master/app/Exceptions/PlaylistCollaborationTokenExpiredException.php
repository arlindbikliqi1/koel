<?php

namespace App\Exceptions;

use Exception;

class PlaylistCollaborationTokenExpiredException extends Exception
{
}
