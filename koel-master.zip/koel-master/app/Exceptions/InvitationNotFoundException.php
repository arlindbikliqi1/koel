<?php

namespace App\Exceptions;

use Exception;

class InvitationNotFoundException extends Exception
{
}
