<?php

namespace App\Exceptions;

use LogicException;

class UserProspectUpdateDeniedException extends LogicException
{
}
