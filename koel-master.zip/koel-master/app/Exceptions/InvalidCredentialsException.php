<?php

namespace App\Exceptions;

use Exception;

class InvalidCredentialsException extends Exception
{
}
